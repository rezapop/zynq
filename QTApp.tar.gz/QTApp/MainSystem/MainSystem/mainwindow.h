#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qFlightInstruments.h"
#include <QTextEdit>
#include "qcgaugewidget.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    QcGaugeWidget * mCompassGauge;
    QcNeedleItem *mCompassNeedle;

    QCompass            *m_Compass;
    QHalfCompass         *m_HalfCompass;
      QADI                *m_ADI_V;
       QADI                *m_ADI_H;
 QTextEdit           *m_helpMsg;
    Ui::MainWindow *ui;

    void keyPressEvent(QKeyEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void resizeEvent(QResizeEvent *event);

};

#endif // MAINWINDOW_H
