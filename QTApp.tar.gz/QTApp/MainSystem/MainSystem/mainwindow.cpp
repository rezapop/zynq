#include "mainwindow.h"
#include "ui_mainwindow.h"


#include <stdio.h>
#include <stdlib.h>

#include <QtCore>
#include <QtGui>
#include <QBoxLayout>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{


    ui->setupUi(this);

    this->setMinimumSize(1280, 720);

        // set focus to this window
        this->setFocus();
     m_ADI_V     = new QADI(this);
     m_ADI_H     = new QADI(this);
    //change frame background color
    ui->frame->setStyleSheet("background-color:black;");
    m_ADI_V->setGeometry(0,400,200,100);
    m_ADI_H->setGeometry(400,550,100,200);
    m_ADI_H->setRoll(90);

     m_Compass  = new QCompass(this);
m_Compass->setGeometry(820 , 30 ,50,50);
m_HalfCompass = new QHalfCompass(this);

m_HalfCompass->setGeometry(1050 , 30 ,50,50);
 m_HalfCompass->setYaw(90);

mCompassGauge = new QcGaugeWidget;




QcLabelItem *n = mCompassGauge->addLabel(40);
n->setText("N");
n->setAngle(90);
n->setColor(Qt::white);


mCompassNeedle = mCompassGauge->addNeedle(40);
mCompassNeedle->setNeedle(QcNeedleItem::CompassNeedle);
mCompassNeedle->setValueRange(-90*10,10*270);
mCompassNeedle->setMaxDegree(10*360);
mCompassNeedle->setMinDegree(0);
mCompassGauge->addBackground(1);

mCompassNeedle->setColor(QColor(255,255,255,255));
  ui->verticalLayout->addWidget(mCompassGauge);
mCompassNeedle->setCurrentValue(-90);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::keyPressEvent(QKeyEvent *event)
{
    int     key;
    double  v,h;

    key = event->key();

    if( key == Qt::Key_Up ) {
        v = m_ADI_V->getPitch();
        m_ADI_V->setPitch(v+1.0);
    } else if ( key == Qt::Key_Down ) {
        v = m_ADI_V->getPitch();
        m_ADI_V->setPitch(v-1.0);
    } else if ( key == Qt::Key_Left ) {
        v = m_ADI_H->getPitch();
        m_ADI_H->setPitch(v-1.0);
    } else if ( key == Qt::Key_Right ) {
        v = m_ADI_H->getPitch();
        m_ADI_H->setPitch(v+1.0);
    }
    else if ( key == Qt::Key_A ) {
            v = m_Compass->getYaw();
            m_Compass->setYaw(v+1.0);

             h=mCompassNeedle->currentValue();
            mCompassNeedle->setCurrentValue(h-1);
       } else if ( key == Qt::Key_D ) {
           v = m_Compass->getYaw();
           m_Compass->setYaw(v-1.0);
           h=mCompassNeedle->currentValue();
           mCompassNeedle->setCurrentValue(h+1);
       }

}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
   QWidget::mousePressEvent(event);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
   QWidget::resizeEvent(event);
}


